---
title: "Datos2"
date: 2021-10-06T14:41:37+02:00   
mensaje: "Página especial para las fotos en `/layouts/docs/datos2.html`"
urldatos: "https://docs.google.com/spreadsheets/d/e/2PACX-1vQbi7wkOO7rqoAdtfGK-uzL03LUCR8VIh8MCxGIgSpdjD8RMjirVsJanKEiwoPXusfCLFjeji1Dt0zS/pub?gid=0&single=true&output=csv"
draft: true
layout: datos2
---
