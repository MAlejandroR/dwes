---
title: "Crear Sitios Estáticos"
linkTitle: "Sitios Estáticos"
weight: 0
date: 2021-09-15
description: >
  Introducción a la creación de sitios estáticos con Hugo
icon: fa-solid fa-browser
draft: false
---



Todo esto, está hecho con el :heart: :smile:  

{{% pageinfo %}}
* Introducción a la generación de sitios web con HUGO
* Crear un sitio estático con hugo
* Instala, configura y agrega contenidos usando una plantilla.
{{% /pageinfo %}}

## ¿Por qué un generador de sitios estáticos?
* Rapidez
* Seguridad
* Eficiencia
* Consistencia de contenidos y formatos
---


# Listado de la teoría:
{{% pageinfo%}}
 **Listado de páginas de referenica**
 ***
 [Manuale sencillos y muy completos](https://cloudcannon.com/community/learn/hugo-beginner-tutorial/)  
>   *****https://cloudcannon.com/community/learn/hugo-beginner-tutorial/*****
{{% /pageinfo%}}