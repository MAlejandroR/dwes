---
title: "Despliegue"
draft: true
description:  "Desplegar el sitio web en github pages y en sitio web creado con vesta"
weight: 30
---

{{% pageinfo %}}
### Objetivos

### Páginas referenciadas

{{% /pageinfo %}}

---
# Que es desplegar
Hay que entender bien, que hasta ahora vemos el despliegue del proyecto en local.
Para hacer un depliegue, necesitamos saber, {{<color>}}previo a generar el sitio {{</color>}} la url donde vamos a subir nuestro proyecto. En este tema vamos a desplegarlo en {{<color>}}git{{</color>}} y en un entorno gestionado por un software llamado {{<color>}}vesta{{</color>}} donde cada uno/a va a tener un usuario y un dominio (y los que os creéis) que gestionar ()
 
## Despliege ne github

github ofrece la posibilidad de ver en funcionamiento tu sitio web usando lo que llaman {{<color>}}github pages{{</color>}}


Vamos a ver cómo hacer el d
# github pages

# Vesta
