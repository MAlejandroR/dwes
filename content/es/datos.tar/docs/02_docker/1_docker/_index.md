---
title: "Docker Prácticas"
linkTitle: "Docker"
weight: 20
menu:
  main:
    weight: 30
icon: fa-brands fa-docker
draft: false    
---

{{% pageinfo %}}
### __:clipboard: Resumen comandos básicos usados con docker__
> :whale: __Instrucciones de comandos en línea de docker__   
> :page_facing_up: Resumen instrucciones usadas en el fichero __Dockerfile__   
> :ship:Resumen estructura __docker-compose.yaml__



* Realizamos unos ejercicios básicos con comandos de docker    
{{% /pageinfo %}}
{{< alert title="Colaboremos" color="warning" >}}
Es importante un feedback para completar esta web, espero vuestras ideas
{{< /alert >}}

