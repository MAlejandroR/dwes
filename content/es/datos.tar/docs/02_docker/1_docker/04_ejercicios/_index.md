---
title: "Docker Prácticas"
linkTitle: "Ejercicios"
weight: 50

icon: fa-solid fa-list-check
  
draft: false    
---

{{< pageinfo >}}
> Ejercicios para practicar con docker

{{< /pageinfo >}}
{{< alert title=" Estructura de los ejercicios" color="warning" >}}
#### :clipboard: Cada página observarás
1. Tendrás un listado de los comandos a utilizar
2. Tendrás un enuniciado muy escueto de una línea
3. En la sesión se abrirá una página con una posible solución  
{{< /alert >}}


