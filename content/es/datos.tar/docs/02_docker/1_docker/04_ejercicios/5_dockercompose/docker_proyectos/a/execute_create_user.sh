mysql -u root < user.sql

