mysql -u root < user.sql
service mysql start
while true
do
  sleep 10
done

