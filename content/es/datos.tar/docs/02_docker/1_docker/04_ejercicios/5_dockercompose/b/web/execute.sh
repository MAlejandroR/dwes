
/usr/sbin/apachectl start
