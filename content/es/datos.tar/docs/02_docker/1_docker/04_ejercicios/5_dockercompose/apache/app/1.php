
<?php

    phpinfo();
    ?>
