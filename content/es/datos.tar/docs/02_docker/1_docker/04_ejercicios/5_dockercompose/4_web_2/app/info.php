<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<a  style="border: solid 1px; background:#DCDFE6; font-size: 2em; color:blue" href="index.html">Volver al index </a>
<h1  style="font-size: 3em; color:brown">INFORMACIÓN DE PHP INSTALADO EN ESTE CONTENEDRO</h1>
<hr />
<?php
phpinfo();
?>

</body>
</html>
