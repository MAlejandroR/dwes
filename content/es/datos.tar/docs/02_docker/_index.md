---
title: "Documentación"
linkTitle: "Dócker"
weight: 20
icon: fa-solid fa-screwdriver-wrench
---

{{% pageinfo %}}
* Aspectos vistos en la tutoría 
* Conceptos / Ejercicios de repaso y refuerzo
{{% /pageinfo %}}

{{% pageinfo color="primary" %}}
> En esta sección se irán aportando recursos que puedan ayudar a adquirir los conceptos estudiados y vistos las tutorías  
Según vayamos avanzando en las clases actualizamos estos puntos.
{{% /pageinfo %}}


